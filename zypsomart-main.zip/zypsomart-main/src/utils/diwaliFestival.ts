/**
 * Diwali Festival Period & Session Helper for Zypsomart.
 * Automatically enables during the Diwali festival window (Dhanteras through Bhai Dooj)
 * and disables once the festival concludes.
 */

const DIWALI_SESSION_KEY = 'zypsomart_diwali_welcome_shown';

// Inclusive [startMonth (1-12), startDay, endMonth (1-12), endDay] per year
const DIWALI_WINDOWS_BY_YEAR: Record<number, [number, number, number, number]> = {
  2025: [10, 18, 10, 24],
  2026: [11, 5, 11, 12],
  2027: [10, 27, 11, 2],
  2028: [10, 15, 10, 21],
  2029: [11, 3, 11, 9],
  2030: [10, 24, 10, 30]
};

export function isDiwaliFestivalPeriod(now: Date = new Date()): boolean {
  try {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const override = params.get('diwali');
      if (override === 'true' || override === '1') return true;
      if (override === 'false' || override === '0') return false;
    }
  } catch {
    // Ignore URL parsing errors
  }

  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const day = now.getDate();

  const windowRange = DIWALI_WINDOWS_BY_YEAR[year];
  if (!windowRange) {
    return false;
  }

  const [startMonth, startDay, endMonth, endDay] = windowRange;
  const currentVal = month * 100 + day;
  const startVal = startMonth * 100 + startDay;
  const endVal = endMonth * 100 + endDay;

  return currentVal >= startVal && currentVal <= endVal;
}

export function shouldShowDiwaliWelcome(): boolean {
  if (typeof window === 'undefined') return false;

  // Do not interrupt Admin dashboard access
  try {
    const params = new URLSearchParams(window.location.search);
    if (params.get('admin') === 'true' || window.location.hash === '#admin') {
      return false;
    }
  } catch {
    // Ignore
  }

  if (!isDiwaliFestivalPeriod()) {
    return false;
  }

  try {
    return sessionStorage.getItem(DIWALI_SESSION_KEY) !== '1';
  } catch {
    return true;
  }
}

export function markDiwaliWelcomeShown(): void {
  try {
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.setItem(DIWALI_SESSION_KEY, '1');
    }
  } catch {
    // Ignore storage quota or private mode errors
  }
}
