import { Product } from '../types';

export interface ResolvedProductOffer {
  originalPrice: number;
  discountedPrice: number;
  discountAmount: number;
  discountPercentage: number;
  offerType: 'percentage' | 'flat' | 'custom';
  offerValue: number;
  startDateMs: number | null;
  endDateMs: number | null;
}

/**
 * Safely parse Firestore Timestamp, Date, epoch ms, ISO string, or YYYY-MM-DD date string.
 * For date-only strings (YYYY-MM-DD), start dates resolve to 00:00:00.000 local time
 * and end dates resolve to 23:59:59.999 local time so offers remain valid through the end date.
 */
export function parseOfferDateMs(value: any, bound: 'start' | 'end'): number | null {
  if (value === null || value === undefined || value === '') return null;

  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : null;
  }

  if (value instanceof Date) {
    const ms = value.getTime();
    return Number.isFinite(ms) ? ms : null;
  }

  if (typeof value === 'object') {
    if (typeof value.toMillis === 'function') {
      const ms = value.toMillis();
      return Number.isFinite(ms) ? ms : null;
    }
    if (typeof value.seconds === 'number') {
      const nanos = typeof value.nanoseconds === 'number' ? value.nanoseconds : 0;
      return value.seconds * 1000 + Math.floor(nanos / 1_000_000);
    }
    if (typeof value._seconds === 'number') {
      const nanos = typeof value._nanoseconds === 'number' ? value._nanoseconds : 0;
      return value._seconds * 1000 + Math.floor(nanos / 1_000_000);
    }
  }

  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return null;

    // Date-only format YYYY-MM-DD
    const dateOnlyMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(trimmed);
    if (dateOnlyMatch) {
      const year = Number(dateOnlyMatch[1]);
      const month = Number(dateOnlyMatch[2]) - 1;
      const day = Number(dateOnlyMatch[3]);
      const dt =
        bound === 'end'
          ? new Date(year, month, day, 23, 59, 59, 999)
          : new Date(year, month, day, 0, 0, 0, 0);
      const ms = dt.getTime();
      return Number.isFinite(ms) ? ms : null;
    }

    const parsed = Date.parse(trimmed);
    return Number.isFinite(parsed) ? parsed : null;
  }

  return null;
}

export function formatOfferPrice(amount: number): string {
  const rounded = Math.round((Number(amount) || 0) * 100) / 100;
  return Number.isInteger(rounded) ? `${rounded}` : rounded.toFixed(2);
}

export function isProductAvailable(product?: Product | null): boolean {
  if (!product) return false;
  if (product.isAvailable === false) return false;
  return product.status === 'Available';
}

/**
 * Resolves and validates an offer stored on a Firestore Product document.
 * Returns null if the offer is disabled, deleted, expired, not yet active, or has no valid discount.
 */
export function resolveProductOffer(
  product?: Product | null,
  nowMs: number = Date.now(),
  options: { requireAvailable?: boolean } = {}
): ResolvedProductOffer | null {
  if (!product) return null;

  if (options.requireAvailable && !isProductAvailable(product)) {
    return null;
  }

  // Must not be explicitly disabled; supports Admin toggling offerEnabled or legacy isOffer
  if (product.offerEnabled === false) return null;
  if (product.isOffer === false && product.offerEnabled !== true) return null;

  const isFlagEnabled =
    product.offerEnabled === true ||
    ((product.offerEnabled === undefined || product.offerEnabled === null) && product.isOffer === true);
  if (!isFlagEnabled) return null;

  // Validate schedule window if dates are configured
  const startDateMs = parseOfferDateMs(product.offerStartDate, 'start');
  const endDateMs = parseOfferDateMs(product.offerEndDate, 'end');

  if (startDateMs !== null && nowMs < startDateMs) {
    return null;
  }
  if (endDateMs !== null && nowMs > endDateMs) {
    return null;
  }

  const originalPrice = Math.round((Number(product.price) || 0) * 100) / 100;
  if (!Number.isFinite(originalPrice) || originalPrice <= 0) {
    return null;
  }

  const rawType = String(product.offerType || '').trim().toLowerCase();
  const rawValue = Number(product.offerValue);
  const hasValidOfferValue = Number.isFinite(rawValue) && rawValue > 0;
  const rawOfferPrice = Number(product.offerPrice);
  const hasExplicitOfferPrice =
    product.offerPrice !== null &&
    product.offerPrice !== undefined &&
    Number.isFinite(rawOfferPrice) &&
    rawOfferPrice > 0 &&
    rawOfferPrice < originalPrice;

  let offerType: 'percentage' | 'flat' | 'custom' = 'custom';
  let discountedPrice = 0;

  const isPercentageType =
    rawType === 'percentage' || rawType === 'percent' || rawType === '%' || rawType.includes('percent');
  const isFlatType =
    rawType === 'flat' ||
    rawType === 'fixed' ||
    rawType === 'amount' ||
    rawType === 'rs' ||
    rawType === 'inr' ||
    rawType.includes('flat') ||
    rawType.includes('fixed');

  if (isPercentageType && hasValidOfferValue && rawValue < 100) {
    offerType = 'percentage';
    const formulaPrice = Math.round(originalPrice * (1 - rawValue / 100) * 100) / 100;
    discountedPrice = hasExplicitOfferPrice
      ? Math.round(rawOfferPrice * 100) / 100
      : formulaPrice;
  } else if (isFlatType && hasValidOfferValue) {
    offerType = 'flat';
    const formulaPrice = Math.round((originalPrice - rawValue) * 100) / 100;
    discountedPrice = hasExplicitOfferPrice
      ? Math.round(rawOfferPrice * 100) / 100
      : formulaPrice;
  } else if (hasExplicitOfferPrice) {
    offerType = 'custom';
    discountedPrice = Math.round(rawOfferPrice * 100) / 100;
  } else {
    return null;
  }

  // Discounted price must strictly be positive and less than original price
  if (!Number.isFinite(discountedPrice) || discountedPrice <= 0 || discountedPrice >= originalPrice) {
    return null;
  }

  const discountAmount = Math.round((originalPrice - discountedPrice) * 100) / 100;
  if (discountAmount <= 0) return null;

  const computedPercent = Math.round((discountAmount / originalPrice) * 100);
  const discountPercentage = Math.max(1, Math.min(99, computedPercent));

  return {
    originalPrice,
    discountedPrice,
    discountAmount,
    discountPercentage,
    offerType,
    offerValue: hasValidOfferValue ? rawValue : discountAmount,
    startDateMs,
    endDateMs
  };
}

export function getEffectiveProductPrice(product: Product, nowMs: number = Date.now()): number {
  const offer = resolveProductOffer(product, nowMs);
  return offer ? offer.discountedPrice : Math.round((Number(product.price) || 0) * 100) / 100;
}
