import React from 'react';
import { Sparkles, Plus, Tag, Flame } from 'lucide-react';
import { Product, CartItem, Language } from '../types';
import { getTranslation } from '../translations';
import { ResolvedProductOffer, formatOfferPrice } from '../utils/offers';

export interface ActiveOfferProduct {
  product: Product;
  offer: ResolvedProductOffer;
}

interface ProductOffersSectionProps {
  offers: ActiveOfferProduct[];
  cart: CartItem[];
  lang: Language;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, e?: React.MouseEvent<HTMLButtonElement>) => void;
  onUpdateQty: (productId: string, delta: number) => void;
}

export function ProductOffersSection({
  offers,
  cart,
  lang,
  onSelectProduct,
  onAddToCart,
  onUpdateQty
}: ProductOffersSectionProps) {
  if (!offers || offers.length === 0) return null;

  const t = (key: string, params?: Record<string, string | number>) => getTranslation(lang, key, params);

  return (
    <section
      id="product-offers-section"
      aria-label={lang === 'hi' ? 'विशेष प्रोडक्ट ऑफर्स' : 'Special Product Offers'}
      className="space-y-3"
    >
      {/* Section Header */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-rose-500 to-orange-500 text-white flex items-center justify-center shadow-xs shrink-0">
            <Flame className="w-4 h-4 fill-current" />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-black text-slate-900 uppercase tracking-wider leading-none">
              {lang === 'hi' ? 'स्पेशल ऑफर्स' : 'Special Offers'}
            </h2>
            <p className="text-[10px] sm:text-[11px] font-semibold text-slate-500 mt-0.5">
              {lang === 'hi' ? 'सीमित समय की महा बचत डील्स' : 'Limited-time savings on fresh picks'}
            </p>
          </div>
        </div>

        <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-700 border border-rose-200 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-tight shrink-0">
          <Sparkles className="w-3 h-3" />
          <span>
            {offers.length} {lang === 'hi' ? 'ऑफर लाइव' : offers.length === 1 ? 'Live Deal' : 'Live Deals'}
          </span>
        </span>
      </div>

      {/* Responsive Horizontal Showcase Track */}
      <div className="flex gap-3 overflow-x-auto overscroll-x-contain hide-scrollbar pb-1.5 snap-x snap-mandatory">
        {offers.map(({ product, offer }) => {
          const quantityInCart = cart.find((item) => item.id === product.id)?.qty || 0;
          const imgSrc =
            product?.imageUrl ||
            product?.image ||
            'https://images.unsplash.com/photo-1542838132-92c53300491e?w=200&auto=format&fit=crop&q=80';

          return (
            <div
              key={product.id}
              onClick={() => onSelectProduct(product)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onSelectProduct(product);
                }
              }}
              className="w-[165px] sm:w-[186px] shrink-0 snap-start bg-gradient-to-b from-rose-50/45 via-white to-white rounded-2xl p-3 border border-rose-200/80 shadow-xs hover:shadow-md hover:border-rose-300 transition-all flex flex-col justify-between cursor-pointer group select-none focus:outline-none focus:ring-2 focus:ring-rose-500/25"
            >
              {/* Product Image + Offer Badges */}
              <div className="bg-white rounded-xl h-28 mb-2.5 flex items-center justify-center p-2 overflow-hidden relative border border-rose-100/80">
                <img
                  referrerPolicy="no-referrer"
                  src={imgSrc}
                  alt={product?.name || 'Offer Product'}
                  className="max-w-full max-h-full object-contain transition-transform duration-300 group-hover:scale-105"
                  onError={(e) => {
                    const target = e.currentTarget as HTMLImageElement;
                    if (!target.dataset.fallbackApplied) {
                      target.dataset.fallbackApplied = 'true';
                      target.src =
                        'https://images.unsplash.com/photo-1542838132-92c53300491e?w=200&auto=format&fit=crop&q=80';
                    }
                  }}
                />

                {/* Discount Percentage Badge */}
                <span className="absolute top-1.5 left-1.5 inline-flex items-center gap-0.5 bg-rose-600 text-white text-[10px] font-black px-2 py-0.5 rounded-lg shadow-xs tracking-tight">
                  <Tag className="w-2.5 h-2.5" />
                  <span>{offer.discountPercentage}% OFF</span>
                </span>

                {/* Offer Banner Strip */}
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-r from-rose-600 to-orange-500 text-white text-[9px] font-black px-2 py-0.5 text-center truncate tracking-wide uppercase">
                  {lang === 'hi'
                    ? `₹${formatOfferPrice(offer.discountAmount)} बचाएं`
                    : `Save ₹${formatOfferPrice(offer.discountAmount)}`}
                </div>
              </div>

              {/* Product Name & Category */}
              <div className="flex flex-col mb-2">
                <h3
                  className="text-xs font-bold text-slate-900 line-clamp-2 leading-snug group-hover:text-rose-700 transition-colors"
                  title={product?.name || 'Item'}
                >
                  {product?.name || 'Item'}
                </h3>
                <span className="text-[10px] text-slate-400 font-semibold mt-0.5 truncate">
                  {product?.category || 'General'}
                </span>
              </div>

              {/* Pricing & Quick Add */}
              <div className="flex items-end justify-between gap-1.5 mt-auto pt-2 border-t border-rose-100/70">
                <div className="flex flex-col min-w-0">
                  <div className="flex items-baseline gap-1.5 flex-wrap">
                    <span className="font-black text-sm text-emerald-700 leading-none">
                      ₹{formatOfferPrice(offer.discountedPrice)}
                    </span>
                    <span className="text-[10px] text-slate-400 line-through font-semibold leading-none">
                      ₹{formatOfferPrice(offer.originalPrice)}
                    </span>
                  </div>
                  <span className="text-[9px] text-slate-400 font-bold uppercase mt-1">
                    / {lang === 'hi' && product?.unit ? t(`units.${(product.unit || '').toLowerCase()}`) || product.unit : (product?.unit || 'kg')}
                  </span>
                </div>

                {quantityInCart > 0 ? (
                  <div
                    className="flex items-center bg-green-50 border border-green-200 rounded-xl p-0.5 shadow-xs shrink-0"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateQty(product.id, -1);
                      }}
                      className="w-6 h-6 flex items-center justify-center font-bold text-green-700 hover:bg-green-100 rounded-lg transition-colors cursor-pointer text-xs"
                      aria-label="Decrease quantity"
                    >
                      -
                    </button>
                    <span className="w-5 text-center text-xs font-black text-green-900">
                      {quantityInCart}
                    </span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateQty(product.id, 1);
                      }}
                      className="w-6 h-6 flex items-center justify-center font-bold text-green-700 hover:bg-green-100 rounded-lg transition-colors cursor-pointer text-xs"
                      aria-label="Increase quantity"
                    >
                      +
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddToCart(product, e);
                    }}
                    className="bg-white border border-green-600 text-green-700 text-[10px] font-black px-3 py-1.5 rounded-xl shadow-xs hover:bg-green-600 hover:text-white transition-all cursor-pointer active:scale-95 flex items-center gap-0.5 shrink-0"
                  >
                    <span>{t('add')}</span>
                    <Plus className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
