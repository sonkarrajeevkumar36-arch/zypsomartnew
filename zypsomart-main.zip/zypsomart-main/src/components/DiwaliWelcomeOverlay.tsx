import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Language } from '../types';

interface DiwaliWelcomeOverlayProps {
  lang: Language;
  onComplete: () => void;
}

interface Rocket {
  x: number;
  y: number;
  vx: number;
  vy: number;
  targetY: number;
  color: string;
  trail: Array<{ x: number; y: number }>;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  alpha: number;
  decay: number;
  size: number;
  color: string;
  twinkle: boolean;
}

interface AmbientSpark {
  x: number;
  y: number;
  vy: number;
  vx: number;
  size: number;
  phase: number;
}

const FIREWORK_COLORS = [
  '#fde047', // Warm Gold
  '#fb923c', // Saffron Orange
  '#f43f5e', // Ruby Rose
  '#34d399', // Festive Emerald
  '#e879f9', // Royal Magenta
  '#38bdf8'  // Sky Spark
];

const LIGHT_BULB_COLORS = [
  '#fbbf24',
  '#f43f5e',
  '#34d399',
  '#fb923c',
  '#e879f9',
  '#fde047'
];

export const DiwaliWelcomeOverlay: React.FC<DiwaliWelcomeOverlayProps> = ({
  lang,
  onComplete
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  const completedRef = useRef(false);

  const triggerExit = useCallback(() => {
    if (completedRef.current) return;
    completedRef.current = true;
    setIsFadingOut(true);
    window.setTimeout(() => {
      onComplete();
    }, 450);
  }, [onComplete]);

  useEffect(() => {
    const mediaQuery =
      typeof window !== 'undefined' && window.matchMedia
        ? window.matchMedia('(prefers-reduced-motion: reduce)')
        : null;
    const reduced = Boolean(mediaQuery?.matches);
    setPrefersReducedMotion(reduced);

    // Auto-transition after 2.4s (total ~2.85s with smooth 450ms fade-out)
    const exitTimer = window.setTimeout(() => {
      triggerExit();
    }, reduced ? 2000 : 2400);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        triggerExit();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.clearTimeout(exitTimer);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [triggerExit]);

  useEffect(() => {
    if (prefersReducedMotion) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationFrameId = 0;
    let width = window.innerWidth;
    let height = window.innerHeight;
    const isCompact = width < 640;

    const updateSize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      // Cap DPR at 1.5 to keep low-end mobile phones fast and cool
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    updateSize();
    window.addEventListener('resize', updateSize, { passive: true });

    const rockets: Rocket[] = [];
    const particles: Particle[] = [];
    const ambientSparks: AmbientSpark[] = [];

    const sparkCount = isCompact ? 20 : 32;
    for (let i = 0; i < sparkCount; i++) {
      ambientSparks.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vy: -(0.25 + Math.random() * 0.55),
        vx: (Math.random() - 0.5) * 0.3,
        size: 1.2 + Math.random() * 2,
        phase: Math.random() * Math.PI * 2
      });
    }

    const spawnRocket = (customX?: number, customTargetY?: number) => {
      const startX = customX ?? width * (0.15 + Math.random() * 0.7);
      const targetY = customTargetY ?? height * (0.14 + Math.random() * 0.28);
      const color = FIREWORK_COLORS[Math.floor(Math.random() * FIREWORK_COLORS.length)];
      rockets.push({
        x: startX,
        y: height + 10,
        vx: (Math.random() - 0.5) * 1.4,
        vy: -(isCompact ? 9.5 : 11) - Math.random() * 2.5,
        targetY,
        color,
        trail: []
      });
    };

    const burstFirework = (x: number, y: number, primaryColor: string) => {
      const count = isCompact ? 26 : 38;
      const secondaryColor =
        FIREWORK_COLORS[Math.floor(Math.random() * FIREWORK_COLORS.length)];

      for (let i = 0; i < count; i++) {
        const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.15;
        const speed = 1.8 + Math.random() * (isCompact ? 4.2 : 5.4);
        particles.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          alpha: 1,
          decay: 0.014 + Math.random() * 0.012,
          size: 1.8 + Math.random() * 2.2,
          color: i % 3 === 0 ? '#fde047' : i % 2 === 0 ? primaryColor : secondaryColor,
          twinkle: Math.random() > 0.45
        });
      }
    };

    // Launch initial celebratory rockets immediately
    spawnRocket(width * 0.25, height * 0.22);
    spawnRocket(width * 0.75, height * 0.2);
    const midTimer = window.setTimeout(() => {
      spawnRocket(width * 0.5, height * 0.16);
      spawnRocket(width * 0.35, height * 0.26);
    }, 450);
    const lateTimer = window.setTimeout(() => {
      spawnRocket(width * 0.65, height * 0.22);
    }, 950);

    let lastTime = performance.now();

    const render = (now: number) => {
      const dt = Math.min((now - lastTime) / 16.667, 2.2);
      lastTime = now;

      ctx.clearRect(0, 0, width, height);

      // 1. Ambient golden particles
      for (let i = 0; i < ambientSparks.length; i++) {
        const s = ambientSparks[i];
        s.x += s.vx * dt;
        s.y += s.vy * dt;
        s.phase += 0.06 * dt;
        if (s.y < -10) {
          s.y = height + 10;
          s.x = Math.random() * width;
        }
        const alpha = 0.35 + 0.55 * Math.sin(s.phase);
        ctx.globalAlpha = Math.max(0.1, alpha);
        ctx.fillStyle = '#fde047';
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
        ctx.fill();
      }

      // 2. Flying Diwali rockets
      for (let i = rockets.length - 1; i >= 0; i--) {
        const r = rockets[i];
        r.trail.push({ x: r.x, y: r.y });
        if (r.trail.length > 7) r.trail.shift();

        r.x += r.vx * dt;
        r.y += r.vy * dt;
        r.vy += 0.12 * dt;

        // Draw rocket tail
        for (let t = 0; t < r.trail.length; t++) {
          const pt = r.trail[t];
          ctx.globalAlpha = ((t + 1) / r.trail.length) * 0.65;
          ctx.fillStyle = '#fbbf24';
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 1.8, 0, Math.PI * 2);
          ctx.fill();
        }

        // Draw rocket head
        ctx.globalAlpha = 1;
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(r.x, r.y, 2.6, 0, Math.PI * 2);
        ctx.fill();

        if (r.y <= r.targetY || r.vy >= -1.2) {
          burstFirework(r.x, r.y, r.color);
          rockets.splice(i, 1);
        }
      }

      // 3. Firework burst particles & crackers
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.vx *= Math.pow(0.965, dt);
        p.vy *= Math.pow(0.965, dt);
        p.vy += 0.065 * dt; // Gentle gravity
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.alpha -= p.decay * dt;

        if (p.alpha <= 0.02) {
          particles.splice(i, 1);
          continue;
        }

        const flicker = p.twinkle ? 0.65 + Math.random() * 0.35 : 1;
        ctx.globalAlpha = Math.max(0, p.alpha * flicker);
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.globalAlpha = 1;
      animationFrameId = window.requestAnimationFrame(render);
    };

    animationFrameId = window.requestAnimationFrame(render);

    return () => {
      window.cancelAnimationFrame(animationFrameId);
      window.clearTimeout(midTimer);
      window.clearTimeout(lateTimer);
      window.removeEventListener('resize', updateSize);
    };
  }, [prefersReducedMotion]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Happy Diwali Celebration"
      className={`fixed inset-0 z-[220] flex flex-col items-center justify-between overflow-hidden select-none transition-all duration-500 ease-out ${
        isFadingOut ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100 scale-100'
      }`}
      style={{
        background:
          'radial-gradient(circle at 50% 38%, #331444 0%, #1b0a28 55%, #0d0415 100%)'
      }}
    >
      {/* Interactive Canvas for Rockets, Fireworks & Golden Sparkles */}
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        className="absolute inset-0 w-full h-full pointer-events-none"
      />

      {/* Top Festive String Lights (Toran) */}
      <div
        aria-hidden="true"
        className="relative z-10 w-full flex items-start justify-around px-2 pt-0 pointer-events-none"
      >
        {Array.from({ length: 11 }).map((_, idx) => {
          const color = LIGHT_BULB_COLORS[idx % LIGHT_BULB_COLORS.length];
          const drop = idx % 2 === 0 ? 'mt-1' : 'mt-3';
          return (
            <div key={idx} className={`flex flex-col items-center ${drop}`}>
              <div className="w-[1.5px] h-3 bg-amber-300/40" />
              <div
                className="w-3 h-3.5 rounded-full animate-diwali-twinkle"
                style={{
                  backgroundColor: color,
                  boxShadow: `0 0 12px 3px ${color}99`,
                  animationDelay: `${idx * 140}ms`
                }}
              />
            </div>
          );
        })}
      </div>

      {/* Top-Right Accessible Skip Button */}
      <div className="absolute top-4 right-4 z-30">
        <button
          type="button"
          onClick={triggerExit}
          aria-label={lang === 'hi' ? 'दिवाली एनीमेशन छोड़ें' : 'Skip Diwali celebration'}
          className="min-h-[44px] px-4 py-2 rounded-full bg-white/15 hover:bg-white/25 active:scale-95 text-amber-100 text-xs font-bold tracking-wide backdrop-blur-md border border-amber-300/30 transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-300"
        >
          {lang === 'hi' ? 'छोड़ें ✕' : 'Skip ✕'}
        </button>
      </div>

      {/* Floating Traditional Indian Sweets (Ladoo, Kaju Katli, Jalebi) */}
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none z-10">
        {/* Top-Left Motichoor Ladoo */}
        <div
          className="absolute top-[18%] left-[7%] sm:left-[14%] opacity-85 animate-diwali-float"
          style={{ animationDelay: '0ms' }}
        >
          <svg width="46" height="46" viewBox="0 0 48 48" fill="none">
            <circle cx="24" cy="24" r="18" fill="url(#ladooGrad)" />
            <circle cx="18" cy="18" r="2.2" fill="#fef08a" opacity="0.8" />
            <circle cx="27" cy="15" r="2" fill="#ea580c" opacity="0.7" />
            <circle cx="31" cy="24" r="2.3" fill="#fef08a" opacity="0.8" />
            <circle cx="21" cy="29" r="2.1" fill="#ea580c" opacity="0.7" />
            <circle cx="28" cy="32" r="1.8" fill="#fef08a" opacity="0.75" />
            <ellipse cx="24" cy="10" rx="4" ry="2" fill="#16a34a" />
            <defs>
              <radialGradient id="ladooGrad" cx="0.35" cy="0.35" r="0.7">
                <stop offset="0%" stopColor="#fde047" />
                <stop offset="55%" stopColor="#f59e0b" />
                <stop offset="100%" stopColor="#d97706" />
              </radialGradient>
            </defs>
          </svg>
        </div>

        {/* Top-Right Kaju Katli */}
        <div
          className="absolute top-[20%] right-[8%] sm:right-[15%] opacity-85 animate-diwali-float"
          style={{ animationDelay: '500ms' }}
        >
          <svg width="46" height="46" viewBox="0 0 48 48" fill="none">
            <path
              d="M24 6L42 24L24 42L6 24L24 6Z"
              fill="url(#katliGrad)"
              stroke="#fde68a"
              strokeWidth="1.5"
            />
            <path
              d="M24 11L37 24L24 37L11 24L24 11Z"
              fill="#ffffff"
              opacity="0.35"
            />
            <defs>
              <linearGradient id="katliGrad" x1="6" y1="6" x2="42" y2="42">
                <stop offset="0%" stopColor="#fef9c3" />
                <stop offset="50%" stopColor="#fde68a" />
                <stop offset="100%" stopColor="#f59e0b" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* Mid-Left Saffron Jalebi */}
        <div
          className="hidden sm:block absolute bottom-[26%] left-[12%] opacity-80 animate-diwali-float"
          style={{ animationDelay: '900ms' }}
        >
          <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
            <path
              d="M24 24C24 20 28 18 31 21C35 25 32 32 25 33C17 34 12 26 15 18C18 10 29 8 36 14C42 20 40 33 31 38"
              stroke="#fb923c"
              strokeWidth="4.2"
              strokeLinecap="round"
            />
            <path
              d="M24 24C24 20 28 18 31 21C35 25 32 32 25 33C17 34 12 26 15 18C18 10 29 8 36 14C42 20 40 33 31 38"
              stroke="#fde047"
              strokeWidth="1.6"
              strokeLinecap="round"
              opacity="0.8"
            />
          </svg>
        </div>
      </div>

      {/* Centerpiece Festive Greeting */}
      <div className="relative z-20 flex flex-col items-center justify-center text-center px-6 my-auto max-w-md">
        {/* Glowing Central Diya Emblem */}
        <div className="relative mb-5 flex items-center justify-center">
          <div
            aria-hidden="true"
            className="absolute w-28 h-28 rounded-full bg-amber-400/25 blur-2xl"
          />
          <svg
            width="76"
            height="76"
            viewBox="0 0 80 80"
            fill="none"
            aria-hidden="true"
            className="relative drop-shadow-[0_0_20px_rgba(251,191,36,0.65)]"
          >
            {/* Flame */}
            <g className="animate-diwali-flame">
              <path
                d="M40 10C40 10 52 24 52 34C52 40.6274 46.6274 46 40 46C33.3726 46 28 40.6274 28 34C28 24 40 10 40 10Z"
                fill="url(#centerFlameOuter)"
              />
              <path
                d="M40 20C40 20 47 29 47 35C47 38.866 43.866 42 40 42C36.134 42 33 38.866 33 35C33 29 40 20 40 20Z"
                fill="#fef9c3"
              />
            </g>
            {/* Diya Bowl */}
            <path
              d="M14 46C14 46 22 49 40 49C58 49 66 46 66 46C64 58 54 66 40 66C26 66 16 58 14 46Z"
              fill="url(#diyaBowlGrad)"
              stroke="#fde047"
              strokeWidth="2"
            />
            <ellipse cx="40" cy="46.5" rx="25" ry="3.5" fill="#fbbf24" opacity="0.45" />
            <defs>
              <linearGradient id="centerFlameOuter" x1="40" y1="10" x2="40" y2="46">
                <stop offset="0%" stopColor="#fde047" />
                <stop offset="55%" stopColor="#f97316" />
                <stop offset="100%" stopColor="#dc2626" />
              </linearGradient>
              <linearGradient id="diyaBowlGrad" x1="14" y1="46" x2="66" y2="66">
                <stop offset="0%" stopColor="#d97706" />
                <stop offset="50%" stopColor="#b45309" />
                <stop offset="100%" stopColor="#78350f" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        <h1
          className="text-4xl sm:text-5xl font-black tracking-tight mb-3 bg-clip-text text-transparent drop-shadow-[0_2px_16px_rgba(251,191,36,0.35)]"
          style={{
            backgroundImage: 'linear-gradient(135deg, #fef08a 0%, #fbbf24 50%, #f97316 100%)'
          }}
        >
          Happy Diwali!
        </h1>

        <p className="text-lg sm:text-xl font-extrabold text-amber-50 tracking-wide leading-snug drop-shadow">
          Celebrate with Zypsomart 🪔
        </p>

        {lang === 'hi' && (
          <p className="mt-2 text-sm font-semibold text-amber-200/90">
            शुभ दीपावली • ज़िप्सोमार्ट के साथ खुशियाँ मनाएँ
          </p>
        )}
      </div>

      {/* Bottom Row of Glowing Diyas */}
      <div
        aria-hidden="true"
        className="relative z-10 w-full max-w-lg flex items-end justify-around pb-6 px-4 pointer-events-none"
      >
        {[0, 1, 2, 3, 4].map((idx) => (
          <div
            key={idx}
            className={`flex flex-col items-center ${
              idx === 0 || idx === 4 ? 'hidden sm:flex' : 'flex'
            }`}
          >
            <div className="w-12 h-12 rounded-full bg-amber-500/20 blur-lg -mb-7" />
            <svg width="44" height="44" viewBox="0 0 48 48" fill="none">
              <g
                className="animate-diwali-flame"
                style={{ animationDelay: `${idx * 180}ms` }}
              >
                <path
                  d="M24 8C24 8 31 17 31 23C31 26.866 27.866 30 24 30C20.134 30 17 26.866 17 23C17 17 24 8 24 8Z"
                  fill="#fb923c"
                />
                <path
                  d="M24 14C24 14 28 19.5 28 23.5C28 25.7091 26.2091 27.5 24 27.5C21.7909 27.5 20 25.7091 20 23.5C20 19.5 24 14 24 14Z"
                  fill="#fef08a"
                />
              </g>
              <path
                d="M8 30C8 30 14 32 24 32C34 32 40 30 40 30C38.5 37.5 32 42 24 42C16 42 9.5 37.5 8 30Z"
                fill="#b45309"
                stroke="#fbbf24"
                strokeWidth="1.5"
              />
            </svg>
          </div>
        ))}
      </div>
    </div>
  );
};
