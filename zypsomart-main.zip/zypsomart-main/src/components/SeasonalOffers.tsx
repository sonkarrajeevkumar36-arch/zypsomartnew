import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Category, Language, Product } from '../types';
import { db } from '../firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { extractColorsFromImage, BannerThemePalette } from '../utils/themeManager';

import defaultBannerImg from '../assets/images/seasonal_banner.png';

export interface BannerSlideItem {
  id: string;
  src: string;
  alt: string;
  categoryKeywords?: string[];
}

export const BANNER_SLIDES: BannerSlideItem[] = [
  {
    id: 'fresh-groceries-home',
    src: defaultBannerImg,
    alt: 'Zypsomart Fresh Groceries & Happy Homes - Daily essentials delivered to your doorstep in 20-30 mins'
  },
  {
    id: 'stationery-essentials',
    src: '/assets/aistudio/Zypsomart_Stationery_Essentials_Banner_967f8149.png',
    alt: 'Zypsomart Stationery Products - Study, office, and daily stationery essentials delivered home',
    categoryKeywords: ['stationary', 'stationery', 'office', 'study']
  },
  {
    id: 'beauty-cosmetics',
    src: '/assets/aistudio/Zypsomart_Beauty_Products_Delivered_471243e7.png',
    alt: 'Zypsomart Cosmetic Products - Top beauty and personal care brands delivered to your doorstep',
    categoryKeywords: ['cosmetic', 'cosmetics', 'beauty', 'personal care', 'skincare']
  },
  {
    id: 'fast-food-feast',
    src: '/assets/aistudio/Zypsomart_Fast_Food_Feast_733fb9fb.png',
    alt: 'Zypsomart Fast Food - Tasty, fresh, hygienic Samosa, Jalebi, Panipuri, Chowmein, Manchurian & Fried Rice',
    categoryKeywords: ['fast food', 'snacks', 'food', 'fastfood']
  }
];

export const SEASONAL_BANNER_IMAGE_URL: string = BANNER_SLIDES[0].src;

const AUTO_SLIDE_INTERVAL_MS = 2000;
const TRANSITION_DURATION_MS = 550;
const SWIPE_THRESHOLD_PX = 42;

export interface SeasonalOffersProps {
  lang?: Language;
  categories?: Category[];
  products?: Product[];
  onSelectOfferCategory?: (categoryName: string) => void;
  onHide?: () => void;
  onHideAll?: () => void;
  bannerUrlOverride?: string;
  onBannerColorExtracted?: (palette: BannerThemePalette) => void;
}

/**
 * SeasonalOffers Component
 * Seamless continuous right-to-left auto-sliding banner carousel (2s interval),
 * touch swipe, desktop hover arrows, and clean indicator tabs below the banner.
 */
export function SeasonalOffers({
  lang = 'en',
  categories = [],
  products = [],
  onSelectOfferCategory,
  bannerUrlOverride,
  onBannerColorExtracted
}: SeasonalOffersProps) {
  const [firestoreBannerUrl, setFirestoreBannerUrl] = useState<string>('');
  const [failedSrcs, setFailedSrcs] = useState<Record<string, boolean>>({});
  const [trackIndex, setTrackIndex] = useState<number>(0);
  const [isTransitionEnabled, setIsTransitionEnabled] = useState<boolean>(true);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState<boolean>(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return false;
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  });

  const touchStartXRef = useRef<number | null>(null);
  const touchStartYRef = useRef<number | null>(null);
  const didSwipeRef = useRef<boolean>(false);
  const slideImgRefs = useRef<Record<string, HTMLImageElement | null>>({});

  // Sync optional remote banner URL from Firestore shopControl if configured
  useEffect(() => {
    try {
      const unsub = onSnapshot(
        doc(db, 'shopControl', 'status'),
        (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.data();
            const remoteUrl = data.seasonalBannerUrl || data.bannerUrl || '';
            if (remoteUrl && typeof remoteUrl === 'string') {
              setFirestoreBannerUrl(remoteUrl.trim());
            } else {
              setFirestoreBannerUrl('');
            }
          }
        },
        (err) => {
          console.warn('[SeasonalOffers Firestore Sync]:', err);
        }
      );
      return () => unsub();
    } catch (err) {
      console.warn('[SeasonalOffers Init Error]:', err);
    }
  }, []);

  // Listen to reduced-motion preference changes
  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const onChange = () => setPrefersReducedMotion(mq.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  const slides = useMemo<BannerSlideItem[]>(() => {
    const list: BannerSlideItem[] = [...BANNER_SLIDES];
    const extraUrl = (bannerUrlOverride || firestoreBannerUrl || '').trim();
    if (
      extraUrl &&
      !list.some((item) => item.src === extraUrl) &&
      extraUrl !== defaultBannerImg
    ) {
      list.push({
        id: 'store-custom-banner',
        src: extraUrl,
        alt: 'Zypsomart Featured Offer'
      });
    }
    return list;
  }, [bannerUrlOverride, firestoreBannerUrl]);

  // Append a clone of the first slide so looping from last -> first continues gliding right-to-left seamlessly
  const renderedSlides = useMemo<BannerSlideItem[]>(() => {
    if (slides.length <= 1) return slides;
    return [...slides, { ...slides[0], id: `${slides[0].id}__clone` }];
  }, [slides]);

  const activeIndex = slides.length > 0 ? trackIndex % slides.length : 0;

  // Keep trackIndex in bounds when slides list changes
  useEffect(() => {
    if (trackIndex > slides.length) {
      setIsTransitionEnabled(false);
      setTrackIndex(0);
    }
  }, [trackIndex, slides.length]);

  // Re-enable smooth CSS transform after an instant wrap snap
  useEffect(() => {
    if (isTransitionEnabled) return;
    let raf1 = 0;
    let raf2 = 0;
    raf1 = window.requestAnimationFrame(() => {
      raf2 = window.requestAnimationFrame(() => {
        setIsTransitionEnabled(true);
      });
    });
    return () => {
      window.cancelAnimationFrame(raf1);
      window.cancelAnimationFrame(raf2);
    };
  }, [isTransitionEnabled]);

  // Fallback snap if transitionend doesn't fire while browser tab is throttled
  useEffect(() => {
    if (slides.length <= 1 || trackIndex !== slides.length) return;
    const fallbackTimer = window.setTimeout(() => {
      setIsTransitionEnabled(false);
      setTrackIndex(0);
    }, TRANSITION_DURATION_MS + 60);
    return () => window.clearTimeout(fallbackTimer);
  }, [trackIndex, slides.length]);

  const handleTrackTransitionEnd = (e: React.TransitionEvent<HTMLDivElement>) => {
    if (e.target !== e.currentTarget || e.propertyName !== 'transform') return;
    if (slides.length > 1 && trackIndex >= slides.length) {
      setIsTransitionEnabled(false);
      setTrackIndex(0);
    }
  };

  const goToSlide = useCallback(
    (index: number) => {
      if (slides.length <= 1) return;
      const normalized = ((index % slides.length) + slides.length) % slides.length;
      setIsTransitionEnabled(true);
      setTrackIndex(normalized);
    },
    [slides.length]
  );

  // Advance seamlessly from right to left (0 -> 1 -> ... -> slides.length -> instant reset to 0)
  const goToNext = useCallback(() => {
    if (slides.length <= 1) return;
    setIsTransitionEnabled(true);
    setTrackIndex((prev) => (prev >= slides.length ? 1 : prev + 1));
  }, [slides.length]);

  const goToPrev = useCallback(() => {
    if (slides.length <= 1) return;
    if (trackIndex <= 0) {
      setIsTransitionEnabled(false);
      setTrackIndex(slides.length);
      window.requestAnimationFrame(() => {
        window.requestAnimationFrame(() => {
          setIsTransitionEnabled(true);
          setTrackIndex(slides.length - 1);
        });
      });
    } else {
      setIsTransitionEnabled(true);
      setTrackIndex(trackIndex - 1);
    }
  }, [trackIndex, slides.length]);

  // Automatic 2-second right-to-left slideshow
  useEffect(() => {
    if (slides.length <= 1 || isPaused || prefersReducedMotion) return;

    const timer = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState === 'hidden') {
        return;
      }
      setIsTransitionEnabled(true);
      setTrackIndex((prev) => (prev >= slides.length ? 1 : prev + 1));
    }, AUTO_SLIDE_INTERVAL_MS);

    return () => window.clearInterval(timer);
  }, [slides.length, isPaused, prefersReducedMotion, activeIndex]);

  // Extract palette from active slide when visible
  useEffect(() => {
    if (!onBannerColorExtracted) return;
    const activeSlide = slides[activeIndex];
    if (!activeSlide) return;
    const img = slideImgRefs.current[activeSlide.id];
    if (img && img.complete && img.naturalWidth > 0) {
      try {
        const palette = extractColorsFromImage(img);
        if (palette) {
          onBannerColorExtracted(palette);
        }
      } catch (e) {
        console.warn('[Banner Palette Pre-extraction Note]:', e);
      }
    }
  }, [activeIndex, slides, onBannerColorExtracted]);

  // Resolve smart category selection on banner click (falls back to 'All')
  const handleSlideClick = (slide: BannerSlideItem) => {
    if (didSwipeRef.current) {
      didSwipeRef.current = false;
      return;
    }

    if (onSelectOfferCategory) {
      let targetCategory = 'All';
      if (slide.categoryKeywords && slide.categoryKeywords.length > 0 && categories.length > 0) {
        const matchedCategory = categories.find((cat) => {
          const catNorm = (cat.normalizedName || cat.name || '').toLowerCase().trim();
          return slide.categoryKeywords!.some(
            (kw) => catNorm === kw || catNorm.includes(kw) || kw.includes(catNorm)
          );
        });

        if (matchedCategory) {
          const matchedNorm = (matchedCategory.normalizedName || matchedCategory.name).toLowerCase().trim();
          const hasProducts =
            products.length === 0 ||
            products.some(
              (p) => (p.normalizedCategory || p.category || '').toLowerCase().trim() === matchedNorm
            );
          if (hasProducts) {
            targetCategory = matchedCategory.name;
          }
        }
      }
      onSelectOfferCategory(targetCategory);
    }

    const productGrid = document.getElementById('products-section');
    if (productGrid) {
      productGrid.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Mobile horizontal touch swipe handlers
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length !== 1) return;
    touchStartXRef.current = e.touches[0].clientX;
    touchStartYRef.current = e.touches[0].clientY;
    didSwipeRef.current = false;
    setIsPaused(true);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (touchStartXRef.current === null || touchStartYRef.current === null) return;
    const dx = Math.abs(e.touches[0].clientX - touchStartXRef.current);
    const dy = Math.abs(e.touches[0].clientY - touchStartYRef.current);
    if (dx > 12 && dx > dy) {
      didSwipeRef.current = true;
    }
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (touchStartXRef.current !== null && e.changedTouches.length > 0) {
      const diffX = e.changedTouches[0].clientX - touchStartXRef.current;
      const diffY =
        touchStartYRef.current !== null
          ? Math.abs(e.changedTouches[0].clientY - touchStartYRef.current)
          : 0;

      if (Math.abs(diffX) >= SWIPE_THRESHOLD_PX && Math.abs(diffX) > diffY) {
        didSwipeRef.current = true;
        if (diffX < 0) {
          goToNext();
        } else {
          goToPrev();
        }
      }
    }
    touchStartXRef.current = null;
    touchStartYRef.current = null;
    setIsPaused(false);
  };

  return (
    <section
      id="seasonal-offers-container"
      className="w-full my-1.5 sm:my-2"
      aria-roledescription="carousel"
      aria-label={lang === 'hi' ? 'विशेष ऑफ़र बैनर स्लाइडर' : 'Featured Offers Banner Slider'}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onFocusCapture={() => setIsPaused(true)}
      onBlurCapture={() => setIsPaused(false)}
    >
      <div
        id="seasonal-banner-card"
        className="relative group w-full rounded-2xl overflow-hidden shadow-xs border border-slate-200/80 bg-white transition-shadow duration-300 hover:shadow-md touch-pan-y"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onKeyDown={(e) => {
          if (e.key === 'ArrowRight') {
            e.preventDefault();
            goToNext();
          } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            goToPrev();
          }
        }}
      >
        {/* Continuous Right-to-Left Sliding Track */}
        <div
          onTransitionEnd={handleTrackTransitionEnd}
          className="flex w-full will-change-transform"
          style={{
            transform: `translate3d(-${trackIndex * 100}%, 0, 0)`,
            transition:
              isTransitionEnabled && !prefersReducedMotion
                ? `transform ${TRANSITION_DURATION_MS}ms cubic-bezier(0.22, 1, 0.36, 1)`
                : 'none'
          }}
        >
          {renderedSlides.map((slide, idx) => {
            const logicalIdx = slides.length > 0 ? idx % slides.length : 0;
            const canonicalId = slides[logicalIdx]?.id || slide.id;
            const hasFailed = Boolean(failedSrcs[canonicalId]);
            const resolvedImageSrc = hasFailed ? defaultBannerImg : slide.src;
            const isClone = idx >= slides.length;

            return (
              <button
                key={slide.id}
                type="button"
                tabIndex={isClone ? -1 : undefined}
                aria-hidden={isClone || undefined}
                onClick={() => handleSlideClick(slide)}
                aria-label={`${slide.alt} (${logicalIdx + 1} of ${slides.length})`}
                className="w-full shrink-0 aspect-[16/9] relative overflow-hidden bg-slate-100 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 focus-visible:ring-inset block p-0 border-0"
              >
                <img
                  ref={(el) => {
                    if (!isClone) {
                      slideImgRefs.current[canonicalId] = el;
                    }
                  }}
                  id={!isClone && logicalIdx === activeIndex ? 'seasonal-banner-img' : undefined}
                  src={resolvedImageSrc}
                  alt={isClone ? '' : slide.alt}
                  onError={() => {
                    if (!hasFailed) {
                      setFailedSrcs((prev) => ({ ...prev, [canonicalId]: true }));
                    }
                  }}
                  onLoad={(e) => {
                    if (!isClone && logicalIdx === activeIndex && onBannerColorExtracted) {
                      const palette = extractColorsFromImage(e.currentTarget);
                      if (palette) {
                        onBannerColorExtracted(palette);
                      }
                    }
                  }}
                  referrerPolicy="no-referrer"
                  loading="eager"
                  draggable={false}
                  className="w-full h-full object-cover object-center block select-none"
                />
              </button>
            );
          })}
        </div>

        {/* Left / Right Navigation Arrows (Desktop hover / focus) */}
        {slides.length > 1 && (
          <>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                goToPrev();
              }}
              aria-label={lang === 'hi' ? 'पिछला बैनर' : 'Previous banner'}
              className="hidden sm:flex items-center justify-center absolute left-3 top-1/2 -translate-y-1/2 z-20 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-slate-800 shadow-md border border-slate-200/80 opacity-0 group-hover:opacity-100 focus-visible:opacity-100 transition-opacity duration-200 cursor-pointer active:scale-95"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                goToNext();
              }}
              aria-label={lang === 'hi' ? 'अगला बैनर' : 'Next banner'}
              className="hidden sm:flex items-center justify-center absolute right-3 top-1/2 -translate-y-1/2 z-20 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-slate-800 shadow-md border border-slate-200/80 opacity-0 group-hover:opacity-100 focus-visible:opacity-100 transition-opacity duration-200 cursor-pointer active:scale-95"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}
      </div>

      {/* Pagination Indicators below banner so 16:9 artwork remains completely unobstructed */}
      {slides.length > 1 && (
        <div
          className="flex items-center justify-center gap-0.5 pt-1"
          role="tablist"
          aria-label={lang === 'hi' ? 'बैनर स्लाइड चुनें' : 'Select banner slide'}
        >
          {slides.map((slide, idx) => {
            const isActive = idx === activeIndex;
            return (
              <button
                key={slide.id}
                type="button"
                role="tab"
                aria-selected={isActive}
                aria-label={`Slide ${idx + 1}: ${slide.alt}`}
                onClick={() => goToSlide(idx)}
                className="p-2 flex items-center justify-center cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 rounded-full"
              >
                <span
                  className={`block h-2 rounded-full transition-all duration-300 ${
                    isActive
                      ? 'w-7 bg-emerald-600'
                      : 'w-2 bg-slate-300 hover:bg-slate-400'
                  }`}
                />
              </button>
            );
          })}
        </div>
      )}
    </section>
  );
}
