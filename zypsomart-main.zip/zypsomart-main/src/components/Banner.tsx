import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { ChevronLeft, ChevronRight, EyeOff } from 'lucide-react';
import { Language } from '../types';
import { getTranslation } from '../translations';
import { BANNER_SLIDES } from './SeasonalOffers';
import defaultBannerImg from '../assets/images/seasonal_banner.png';

interface BannerProps {
  lang: Language;
  onHide?: () => void;
}

const AUTO_SLIDE_INTERVAL_MS = 2000;
const TRANSITION_DURATION_MS = 550;
const SWIPE_THRESHOLD_PX = 42;

export function Banner({ lang, onHide }: BannerProps) {
  const t = (key: string, params?: Record<string, string | number>) => getTranslation(lang, key, params);

  const slides = BANNER_SLIDES;
  const renderedSlides = useMemo(() => {
    if (slides.length <= 1) return slides;
    return [...slides, { ...slides[0], id: `${slides[0].id}__banner_clone` }];
  }, [slides]);

  const [trackIndex, setTrackIndex] = useState<number>(0);
  const [isTransitionEnabled, setIsTransitionEnabled] = useState<boolean>(true);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [failedSrcs, setFailedSrcs] = useState<Record<string, boolean>>({});
  const [prefersReducedMotion, setPrefersReducedMotion] = useState<boolean>(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return false;
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  });

  const touchStartXRef = useRef<number | null>(null);
  const touchStartYRef = useRef<number | null>(null);

  const activeIndex = slides.length > 0 ? trackIndex % slides.length : 0;

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const onChange = () => setPrefersReducedMotion(mq.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  useEffect(() => {
    if (isTransitionEnabled) return;
    let raf1 = 0;
    let raf2 = 0;
    raf1 = window.requestAnimationFrame(() => {
      raf2 = window.requestAnimationFrame(() => {
        setIsTransitionEnabled(true);
      });
    });
    return () => {
      window.cancelAnimationFrame(raf1);
      window.cancelAnimationFrame(raf2);
    };
  }, [isTransitionEnabled]);

  useEffect(() => {
    if (slides.length <= 1 || trackIndex !== slides.length) return;
    const fallbackTimer = window.setTimeout(() => {
      setIsTransitionEnabled(false);
      setTrackIndex(0);
    }, TRANSITION_DURATION_MS + 60);
    return () => window.clearTimeout(fallbackTimer);
  }, [trackIndex, slides.length]);

  const handleTrackTransitionEnd = (e: React.TransitionEvent<HTMLDivElement>) => {
    if (e.target !== e.currentTarget || e.propertyName !== 'transform') return;
    if (slides.length > 1 && trackIndex >= slides.length) {
      setIsTransitionEnabled(false);
      setTrackIndex(0);
    }
  };

  const goToSlide = useCallback(
    (index: number) => {
      if (slides.length <= 1) return;
      const normalized = ((index % slides.length) + slides.length) % slides.length;
      setIsTransitionEnabled(true);
      setTrackIndex(normalized);
    },
    [slides.length]
  );

  const goToNext = useCallback(() => {
    if (slides.length <= 1) return;
    setIsTransitionEnabled(true);
    setTrackIndex((prev) => (prev >= slides.length ? 1 : prev + 1));
  }, [slides.length]);

  const goToPrev = useCallback(() => {
    if (slides.length <= 1) return;
    if (trackIndex <= 0) {
      setIsTransitionEnabled(false);
      setTrackIndex(slides.length);
      window.requestAnimationFrame(() => {
        window.requestAnimationFrame(() => {
          setIsTransitionEnabled(true);
          setTrackIndex(slides.length - 1);
        });
      });
    } else {
      setIsTransitionEnabled(true);
      setTrackIndex(trackIndex - 1);
    }
  }, [trackIndex, slides.length]);

  // Automatic 2-second right-to-left slideshow
  useEffect(() => {
    if (slides.length <= 1 || isPaused || prefersReducedMotion) return;

    const timer = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState === 'hidden') {
        return;
      }
      setIsTransitionEnabled(true);
      setTrackIndex((prev) => (prev >= slides.length ? 1 : prev + 1));
    }, AUTO_SLIDE_INTERVAL_MS);

    return () => window.clearInterval(timer);
  }, [slides.length, isPaused, prefersReducedMotion, activeIndex]);

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length !== 1) return;
    touchStartXRef.current = e.touches[0].clientX;
    touchStartYRef.current = e.touches[0].clientY;
    setIsPaused(true);
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (touchStartXRef.current !== null && e.changedTouches.length > 0) {
      const diffX = e.changedTouches[0].clientX - touchStartXRef.current;
      const diffY =
        touchStartYRef.current !== null
          ? Math.abs(e.changedTouches[0].clientY - touchStartYRef.current)
          : 0;

      if (Math.abs(diffX) >= SWIPE_THRESHOLD_PX && Math.abs(diffX) > diffY) {
        if (diffX < 0) {
          goToNext();
        } else {
          goToPrev();
        }
      }
    }
    touchStartXRef.current = null;
    touchStartYRef.current = null;
    setIsPaused(false);
  };

  return (
    <div
      className="relative overflow-hidden group"
      aria-roledescription="carousel"
      aria-label={lang === 'hi' ? 'प्रचार बैनर स्लाइडशो' : 'Promotional Banner Slideshow'}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onFocusCapture={() => setIsPaused(true)}
      onBlurCapture={() => setIsPaused(false)}
    >
      <div
        className="relative rounded-2xl w-full overflow-hidden shadow-md border border-slate-200/80 bg-white touch-pan-y"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {/* Hide Banner Button */}
        {onHide && (
          <button
            id="hide-promo-banner-btn"
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onHide();
            }}
            title={t('hideBanner')}
            className="absolute top-3 right-3 z-30 flex items-center gap-1.5 bg-black/45 hover:bg-black/75 backdrop-blur-md text-white/95 hover:text-white text-[11px] font-bold px-2.5 py-1 rounded-full border border-white/20 transition-all cursor-pointer active:scale-95 shadow-xs"
          >
            <EyeOff className="w-3 h-3 text-white/85" />
            <span className="text-[10px] uppercase tracking-wider">{t('hideBanner')}</span>
          </button>
        )}

        {/* Right-to-Left Sliding Track */}
        <div
          onTransitionEnd={handleTrackTransitionEnd}
          className="flex w-full will-change-transform"
          style={{
            transform: `translate3d(-${trackIndex * 100}%, 0, 0)`,
            transition:
              isTransitionEnabled && !prefersReducedMotion
                ? `transform ${TRANSITION_DURATION_MS}ms cubic-bezier(0.22, 1, 0.36, 1)`
                : 'none'
          }}
        >
          {renderedSlides.map((slide, idx) => {
            const logicalIdx = slides.length > 0 ? idx % slides.length : 0;
            const canonicalId = slides[logicalIdx]?.id || slide.id;
            const hasFailed = Boolean(failedSrcs[canonicalId]);
            const resolvedImageSrc = hasFailed ? defaultBannerImg : slide.src;
            const isClone = idx >= slides.length;

            return (
              <div
                key={slide.id}
                aria-hidden={isClone || undefined}
                className="w-full shrink-0 aspect-[16/9] relative overflow-hidden bg-slate-100"
              >
                <img
                  src={resolvedImageSrc}
                  alt={isClone ? '' : slide.alt}
                  onError={() => {
                    if (!hasFailed) {
                      setFailedSrcs((prev) => ({ ...prev, [canonicalId]: true }));
                    }
                  }}
                  referrerPolicy="no-referrer"
                  loading="eager"
                  draggable={false}
                  className="w-full h-full object-cover object-center block select-none"
                />
              </div>
            );
          })}
        </div>

        {/* Left / Right Navigation Arrows */}
        {slides.length > 1 && (
          <>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                goToPrev();
              }}
              aria-label={lang === 'hi' ? 'पिछला बैनर' : 'Previous banner'}
              className="hidden sm:flex items-center justify-center absolute left-3 top-1/2 -translate-y-1/2 z-20 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-slate-800 shadow-md border border-slate-200/80 opacity-0 group-hover:opacity-100 focus-visible:opacity-100 transition-opacity duration-200 cursor-pointer active:scale-95"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                goToNext();
              }}
              aria-label={lang === 'hi' ? 'अगला बैनर' : 'Next banner'}
              className="hidden sm:flex items-center justify-center absolute right-3 top-1/2 -translate-y-1/2 z-20 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-slate-800 shadow-md border border-slate-200/80 opacity-0 group-hover:opacity-100 focus-visible:opacity-100 transition-opacity duration-200 cursor-pointer active:scale-95"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}
      </div>

      {/* Pagination Indicators */}
      {slides.length > 1 && (
        <div
          className="flex items-center justify-center gap-0.5 pt-1"
          role="tablist"
          aria-label={lang === 'hi' ? 'बैनर स्लाइड चुनें' : 'Select banner slide'}
        >
          {slides.map((slide, idx) => {
            const isActive = idx === activeIndex;
            return (
              <button
                key={slide.id}
                type="button"
                role="tab"
                aria-selected={isActive}
                aria-label={`Slide ${idx + 1}: ${slide.alt}`}
                onClick={() => goToSlide(idx)}
                className="p-2 flex items-center justify-center cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 rounded-full"
              >
                <span
                  className={`block h-2 rounded-full transition-all duration-300 ${
                    isActive
                      ? 'w-7 bg-emerald-600'
                      : 'w-2 bg-slate-300 hover:bg-slate-400'
                  }`}
                />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
