import React from 'react';
import {
  Check,
  ShoppingBag,
  BadgeCheck,
  Package,
  Bike,
  Home
} from 'lucide-react';
import { Language } from '../types';

export function getOrderTrackingStepIndex(status: string): number {
  const s = (status || '').toLowerCase().trim();
  if (s === 'delivered') return 4;
  if (
    s === 'out for delivery' ||
    s === 'out_for_delivery' ||
    s === 'on the way' ||
    s === 'on_the_way'
  ) {
    return 3;
  }
  if (s === 'preparing' || s === 'packaging') return 2;
  if (s === 'accepted') return 1;
  if (s === 'placed' || s === 'pending') return 0;
  return -1;
}

export function isOrderActiveStatus(status: string): boolean {
  const step = getOrderTrackingStepIndex(status);
  return step >= 0 && step < 4;
}

function DeliveryMotorcycleRiderSvg() {
  return (
    <svg
      width="48"
      height="30"
      viewBox="0 0 64 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      className="drop-shadow-xs select-none"
    >
      {/* Trailing speed wind streaks */}
      <g className="animate-rider-wind">
        <line x1="1" y1="15" x2="9" y2="15" stroke="#10b981" strokeWidth="1.6" strokeLinecap="round" opacity="0.7" />
        <line x1="3" y1="20" x2="10" y2="20" stroke="#34d399" strokeWidth="1.4" strokeLinecap="round" opacity="0.6" />
        <line x1="0" y1="25" x2="7" y2="25" stroke="#10b981" strokeWidth="1.2" strokeLinecap="round" opacity="0.5" />
      </g>

      <g className="animate-rider-bounce">
        {/* Rear Wheel */}
        <g className="animate-rider-wheel">
          <circle cx="19" cy="31" r="6.5" fill="#1e293b" />
          <circle cx="19" cy="31" r="3.5" fill="#e2e8f0" />
          <line x1="19" y1="27.5" x2="19" y2="34.5" stroke="#475569" strokeWidth="1.1" />
          <line x1="15.5" y1="31" x2="22.5" y2="31" stroke="#475569" strokeWidth="1.1" />
        </g>

        {/* Front Wheel */}
        <g className="animate-rider-wheel">
          <circle cx="48" cy="31" r="6.5" fill="#1e293b" />
          <circle cx="48" cy="31" r="3.5" fill="#e2e8f0" />
          <line x1="48" y1="27.5" x2="48" y2="34.5" stroke="#475569" strokeWidth="1.1" />
          <line x1="44.5" y1="31" x2="51.5" y2="31" stroke="#475569" strokeWidth="1.1" />
        </g>

        {/* Exhaust pipe */}
        <path d="M12 29.5H25" stroke="#64748b" strokeWidth="2.2" strokeLinecap="round" />

        {/* Scooter / Motorcycle Chassis */}
        <path
          d="M17 26.5C19.5 22 24.5 21 29 22.5L38 24.5L43 16.5L47 18.5L43.5 28.5H27C24 28.5 21.5 27.8 17 26.5Z"
          fill="#16a34a"
        />
        {/* Front fork & mudguard */}
        <path d="M43 17.5L48 31" stroke="#0f172a" strokeWidth="2.4" strokeLinecap="round" />
        <path d="M42.5 25.5C45.5 23 50.5 23 53 26" stroke="#15803d" strokeWidth="2.2" strokeLinecap="round" />

        {/* Headlight & soft beam */}
        <circle cx="48.5" cy="18.5" r="2.2" fill="#fbbf24" />
        <path d="M51 17.5L62 15.5V21.5L51 19.5Z" fill="#fde68a" opacity="0.45" />

        {/* Delivery Cargo Box on Back */}
        <rect x="10.5" y="13" width="12.5" height="10" rx="2.2" fill="#059669" stroke="#ffffff" strokeWidth="1" />
        <path d="M14 16.2H19.5L14.5 20.2H19.8" stroke="#ffffff" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />

        {/* Rider Legs & Foot */}
        <path d="M29 20.5L34.5 25.5L32.5 29" stroke="#1e293b" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />

        {/* Rider Torso (Green Jacket) */}
        <path
          d="M26 14.5C26 12.8 28 11.8 30.2 12.2L35 13.8L32.5 21.5H26.5L26 14.5Z"
          fill="#22c55e"
        />

        {/* Rider Arm reaching handlebar */}
        <path d="M32.5 14.5L41.5 16.5" stroke="#166534" strokeWidth="2.4" strokeLinecap="round" />

        {/* Handlebar */}
        <path d="M40.5 15.5L44 16.5" stroke="#0f172a" strokeWidth="2.2" strokeLinecap="round" />

        {/* Rider Helmet & Visor */}
        <circle cx="32.5" cy="8.2" r="4.4" fill="#0f172a" />
        <path d="M33.2 6.8C35.2 6.8 36.7 7.8 36.7 9.1H33.2V6.8Z" fill="#38bdf8" />
        <circle cx="32" cy="8.2" r="4.4" stroke="#10b981" strokeWidth="0.9" />
      </g>
    </svg>
  );
}

interface OrderTrackingStepperProps {
  status: string;
  lang: Language;
  rightActionSlot?: React.ReactNode;
  children?: React.ReactNode;
}

export function OrderTrackingStepper({
  status,
  lang,
  rightActionSlot,
  children
}: OrderTrackingStepperProps) {
  const stepIndex = getOrderTrackingStepIndex(status);
  if (stepIndex < 0) return null;

  const isOnTheWay = stepIndex === 3;
  const isDelivered = stepIndex === 4;

  const stages = [
    {
      key: 'placed',
      label: lang === 'hi' ? 'प्राप्त' : 'Placed',
      Icon: ShoppingBag
    },
    {
      key: 'accepted',
      label: lang === 'hi' ? 'स्वीकृत' : 'Accepted',
      Icon: BadgeCheck
    },
    {
      key: 'packaging',
      label: lang === 'hi' ? 'पैकिंग' : 'Packaging',
      Icon: Package
    },
    {
      key: 'on_the_way',
      label: lang === 'hi' ? 'रास्ते में' : 'On the Way',
      Icon: Bike
    },
    {
      key: 'delivered',
      label: lang === 'hi' ? 'डिलीवर' : 'Delivered',
      Icon: Home
    }
  ];

  const getStatusMessage = () => {
    switch (stepIndex) {
      case 0:
        return lang === 'hi'
          ? 'आपका ऑर्डर स्टोर तक पहुँच गया है'
          : 'Order received and awaiting store confirmation';
      case 1:
        return lang === 'hi'
          ? 'स्टोर ने आपका ऑर्डर स्वीकार कर लिया है'
          : 'Store accepted your order and queued it for packing';
      case 2:
        return lang === 'hi'
          ? 'आपके ताज़ा सामान की पैकिंग की जा रही है'
          : 'Items are being freshly packed for dispatch';
      case 3:
        return lang === 'hi'
          ? 'डिलीवरी पार्टनर आपके पते की ओर आ रहा है'
          : 'Delivery partner is riding toward your location';
      case 4:
        return lang === 'hi'
          ? 'ऑर्डर सफलतापूर्वक डिलीवर हो गया है'
          : 'Order has been delivered to your doorstep';
      default:
        return '';
    }
  };

  return (
    <div className="bg-slate-50/95 rounded-2xl p-3.5 sm:p-4 border border-slate-200/75 space-y-2.5">
      {/* Delivery Boy Riding Motorcycle Animation (Visible ONLY when status is "On the Way") */}
      {isOnTheWay && (
        <div
          className="relative h-8 w-full overflow-hidden pointer-events-none"
          aria-label={lang === 'hi' ? 'डिलीवरी राइडर रास्ते में है' : 'Delivery rider on the way'}
        >
          {/* Subtle road lane near On the Way -> Delivered */}
          <div className="absolute bottom-0.5 left-[54%] right-[8%] border-b border-dashed border-emerald-300/80" />
          <div className="absolute bottom-0 left-[63%] sm:left-[65%] animate-rider-cruise">
            <DeliveryMotorcycleRiderSvg />
          </div>
        </div>
      )}

      {/* 5-Stage Horizontal Stepper */}
      <div className="relative">
        {/* Background & Active Connecting Progress Line (centers of Col 1 to Col 5) */}
        <div
          className="absolute left-[10%] right-[10%] top-[18px] sm:top-[20px] h-1 bg-slate-200 rounded-full overflow-hidden z-0"
          aria-hidden="true"
        >
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-green-600 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${(stepIndex / 4) * 100}%` }}
          />
        </div>

        {/* 5 Step Columns */}
        <div className="grid grid-cols-5 relative z-10">
          {stages.map((stage, idx) => {
            const isCompleted = idx < stepIndex;
            const isCurrent = idx === stepIndex;
            const isUpcoming = idx > stepIndex;
            const StageIcon = stage.Icon;

            return (
              <div key={stage.key} className="flex flex-col items-center">
                {/* Fixed-height circle wrapper keeps line centered across varying circle sizes */}
                <div className="h-9 sm:h-10 flex items-center justify-center">
                  {isCurrent ? (
                    <div
                      className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center ring-4 ring-emerald-100 shadow-md shadow-emerald-600/25 transition-all duration-300"
                      aria-current="step"
                    >
                      {isDelivered ? (
                        <Check className="w-4 h-4 sm:w-5 sm:h-5 stroke-[3]" />
                      ) : (
                        <StageIcon className="w-4 h-4 sm:w-[18px] sm:h-[18px]" />
                      )}
                    </div>
                  ) : isCompleted ? (
                    <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-2xs transition-all duration-300">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                  ) : (
                    <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-slate-200 text-slate-400 border border-slate-200 flex items-center justify-center transition-all duration-300">
                      <span className="w-2 h-2 rounded-full bg-slate-400/70" />
                    </div>
                  )}
                </div>

                {/* Stage Title */}
                <span
                  className={`mt-1.5 text-center text-[10px] sm:text-[11px] leading-tight px-0.5 sm:whitespace-nowrap ${
                    isCurrent
                      ? 'font-black text-emerald-800'
                      : isCompleted
                      ? 'font-bold text-emerald-700'
                      : isUpcoming
                      ? 'font-semibold text-slate-400'
                      : 'font-semibold text-slate-500'
                  }`}
                >
                  {stage.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Status description + Optional Track on Map action */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-200/60">
        <p
          className={`text-[11px] font-semibold ${
            isDelivered ? 'text-emerald-700' : 'text-slate-600'
          }`}
        >
          {getStatusMessage()}
        </p>

        {rightActionSlot}
      </div>

      {children}
    </div>
  );
}
