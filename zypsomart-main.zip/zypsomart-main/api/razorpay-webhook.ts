/**
 * Self-contained Vercel Serverless & Edge API endpoint for Razorpay webhooks.
 * Zero external relative imports to eliminate ERR_MODULE_NOT_FOUND and FUNCTION_INVOCATION_FAILED.
 */

export const config = {
  runtime: 'edge',
};

const CORS_HEADERS: Record<string, string> = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, x-razorpay-signature',
};

function getCredentials(env?: any): { keySecret: string } {
  const safeEnv = env || {};
  const rawKeySecret =
    safeEnv.RAZORPAY_KEY_SECRET ||
    safeEnv.RAZORPAY_SECRET ||
    safeEnv.RAZORPAY_LIVE_KEY_SECRET ||
    safeEnv.RAZORPAY_API_SECRET ||
    safeEnv.razorpay_key_secret ||
    (typeof process !== 'undefined' ? process.env?.RAZORPAY_KEY_SECRET || process.env?.RAZORPAY_SECRET || process.env?.RAZORPAY_LIVE_KEY_SECRET || process.env?.razorpay_key_secret : '') ||
    '';

  return {
    keySecret: String(rawKeySecret).trim()
  };
}

async function verifyWebhookHmac(rawBody: string, signature: string, secret: string): Promise<boolean> {
  if (!rawBody || !signature || !secret) return false;

  try {
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );

    const sigBuf = await crypto.subtle.sign('HMAC', key, encoder.encode(rawBody));
    const hashArr = Array.from(new Uint8Array(sigBuf));
    const calculated = hashArr.map((b) => b.toString(16).padStart(2, '0')).join('');

    if (calculated.length !== signature.length) return false;
    let res = 0;
    for (let i = 0; i < calculated.length; i++) {
      res |= calculated.charCodeAt(i) ^ signature.toLowerCase().charCodeAt(i);
    }
    return res === 0;
  } catch (err) {
    console.error('[Webhook HMAC Error]:', err);
    return false;
  }
}

export default async function handler(req: any, res?: any) {
  // If invoked with Node.js (req, res)
  if (res && typeof res.status === 'function') {
    for (const [k, v] of Object.entries(CORS_HEADERS)) {
      res.setHeader(k, v);
    }
    if (req.method === 'OPTIONS') return res.status(204).end();

    if (req.method === 'GET') {
      return res.status(200).json({ success: true, service: 'Zypsomart Razorpay Webhook Endpoint', status: 'active' });
    }

    const { keySecret } = getCredentials();
    const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET || keySecret;
    const signature = req.headers['x-razorpay-signature'] as string;

    if (!webhookSecret) {
      return res.status(500).json({ success: false, error: 'Webhook secret not configured' });
    }
    if (!signature) {
      return res.status(400).json({ success: false, error: 'Missing x-razorpay-signature header' });
    }

    const raw = typeof req.body === 'string' ? req.body : JSON.stringify(req.body || {});
    const isValid = await verifyWebhookHmac(raw, signature, webhookSecret);
    if (!isValid) {
      return res.status(400).json({ success: false, error: 'Invalid webhook signature' });
    }

    return res.status(200).json({ success: true, verified: true, received: true });
  }

  // Web Standard / Edge Mode
  const method = req.method;
  if (method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }

  if (method === 'GET') {
    return new Response(
      JSON.stringify({ success: true, service: 'Zypsomart Razorpay Webhook Endpoint', status: 'active' }),
      { status: 200, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
    );
  }

  const { keySecret } = getCredentials();
  const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET || keySecret;
  const signature = req.headers.get('x-razorpay-signature');

  if (!webhookSecret || !signature) {
    return new Response(JSON.stringify({ success: false, error: 'Missing webhook configuration' }), {
      status: 400,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' }
    });
  }

  const rawBody = await req.text();
  const isValid = await verifyWebhookHmac(rawBody, signature, webhookSecret);
  if (!isValid) {
    return new Response(JSON.stringify({ success: false, error: 'Invalid webhook signature' }), {
      status: 400,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' }
    });
  }

  return new Response(JSON.stringify({ success: true, verified: true }), {
    status: 200,
    headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' }
  });
}
