/**
 * Rock-solid Vercel Serverless API endpoint for verifying Razorpay payment signatures.
 * Uses standard Node.js serverless runtime for maximum stability and zero FUNCTION_INVOCATION_FAILED errors.
 */

const CORS_HEADERS: Record<string, string> = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, x-razorpay-signature',
};

function getCredentials(env?: any): { keySecret: string } {
  const safeEnv = env || {};
  const rawKeySecret =
    safeEnv.RAZORPAY_KEY_SECRET ||
    safeEnv.RAZORPAY_SECRET ||
    safeEnv.RAZORPAY_LIVE_KEY_SECRET ||
    safeEnv.RAZORPAY_API_SECRET ||
    safeEnv.razorpay_key_secret ||
    (typeof process !== 'undefined' && process.env ? process.env.RAZORPAY_KEY_SECRET || process.env.RAZORPAY_SECRET || process.env.RAZORPAY_LIVE_KEY_SECRET || process.env.razorpay_key_secret : '') ||
    '';

  return {
    keySecret: String(rawKeySecret).trim()
  };
}

async function verifyHmac(orderId: string, paymentId: string, signature: string, secret: string): Promise<boolean> {
  if (!orderId || !paymentId || !signature || !secret) return false;

  try {
    // If running in Node.js environment with crypto module
    if (typeof process !== 'undefined' && typeof require === 'function') {
      try {
        const crypto = require('crypto');
        const expected = crypto
          .createHmac('sha256', secret)
          .update(`${orderId}|${paymentId}`)
          .digest('hex');
        return crypto.timingSafeEqual(Buffer.from(expected.toLowerCase()), Buffer.from(signature.toLowerCase()));
      } catch {}
    }

    // Web Crypto subtle fallback
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );

    const payload = `${orderId}|${paymentId}`;
    const sigBuf = await crypto.subtle.sign('HMAC', key, encoder.encode(payload));
    const hashArr = Array.from(new Uint8Array(sigBuf));
    const calculated = hashArr.map((b) => b.toString(16).padStart(2, '0')).join('');

    if (calculated.length !== signature.length) return false;
    let res = 0;
    for (let i = 0; i < calculated.length; i++) {
      res |= calculated.charCodeAt(i) ^ signature.toLowerCase().charCodeAt(i);
    }
    return res === 0;
  } catch (err) {
    console.error('[HMAC Verification Error]:', err);
    return false;
  }
}

export default async function handler(req: any, res?: any) {
  try {
    // Node.js Serverless Mode
    if (res && typeof res.status === 'function') {
      for (const [k, v] of Object.entries(CORS_HEADERS)) {
        res.setHeader(k, v);
      }
      if (req.method === 'OPTIONS') return res.status(204).end();

      const { keySecret } = getCredentials();
      if (req.method === 'GET') {
        return res.status(200).json({
          success: true,
          service: 'Zypsomart Payment Verification API',
          status: 'ready',
          secretConfigured: Boolean(keySecret)
        });
      }

      if (req.method !== 'POST') {
        return res.status(405).json({ success: false, error: 'Method not allowed' });
      }

      if (!keySecret) {
        return res.status(500).json({
          success: false,
          error: 'RAZORPAY_KEY_SECRET is not configured in Vercel Environment Variables.'
        });
      }

      let body = req.body;
      if (typeof body === 'string') {
        try { body = JSON.parse(body); } catch { body = {}; }
      }
      body = body || {};

      const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = body;
      if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
        return res.status(400).json({
          success: false,
          error: 'Missing required Razorpay payment verification fields.'
        });
      }

      const isValid = await verifyHmac(razorpay_order_id, razorpay_payment_id, razorpay_signature, keySecret);
      if (!isValid) {
        console.warn('[Signature Invalid]:', { orderId: String(razorpay_order_id).slice(-8) });
        return res.status(400).json({
          success: false,
          verified: false,
          error: 'Payment signature verification failed. Transaction was not verified.'
        });
      }

      return res.status(200).json({
        success: true,
        verified: true,
        paymentId: razorpay_payment_id,
        orderId: razorpay_order_id
      });
    }

    // Web Standard Request Mode Fallback
    const method = req.method;
    if (method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: CORS_HEADERS });
    }

    const { keySecret } = getCredentials();
    if (method === 'GET') {
      return new Response(
        JSON.stringify({
          success: true,
          service: 'Zypsomart Payment Verification API',
          status: 'ready',
          secretConfigured: Boolean(keySecret)
        }),
        { status: 200, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
      );
    }

    if (method !== 'POST') {
      return new Response(JSON.stringify({ success: false, error: 'Method not allowed' }), {
        status: 405,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' }
      });
    }

    if (!keySecret) {
      return new Response(
        JSON.stringify({
          success: false,
          error: 'RAZORPAY_KEY_SECRET is not configured in Vercel Environment Variables.'
        }),
        { status: 500, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
      );
    }

    const body = await req.json().catch(() => ({}));
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return new Response(
        JSON.stringify({ success: false, error: 'Missing required Razorpay payment verification fields.' }),
        { status: 400, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
      );
    }

    const isValid = await verifyHmac(razorpay_order_id, razorpay_payment_id, razorpay_signature, keySecret);
    if (!isValid) {
      return new Response(
        JSON.stringify({ success: false, verified: false, error: 'Payment signature verification failed.' }),
        { status: 400, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        verified: true,
        paymentId: razorpay_payment_id,
        orderId: razorpay_order_id
      }),
      { status: 200, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
    );
  } catch (err: any) {
    if (res && typeof res.status === 'function') {
      return res.status(500).json({ success: false, error: err?.message || 'Server error during verification' });
    }
    return new Response(
      JSON.stringify({ success: false, error: err?.message || 'Server error during verification' }),
      { status: 500, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
    );
  }
}
