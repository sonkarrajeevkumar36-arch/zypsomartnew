/**
 * Rock-solid Vercel Serverless API endpoint for creating Razorpay orders.
 * Uses standard Node.js serverless runtime for maximum stability and zero FUNCTION_INVOCATION_FAILED errors.
 */

const CORS_HEADERS: Record<string, string> = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, x-razorpay-signature',
};

function getCredentials(env?: any): { keyId: string; keySecret: string } {
  const safeEnv = env || {};
  const rawKeyId =
    safeEnv.RAZORPAY_KEY_ID ||
    safeEnv.VITE_RAZORPAY_KEY_ID ||
    safeEnv.RAZORPAY_LIVE_KEY_ID ||
    safeEnv.RAZORPAY_API_KEY ||
    safeEnv.razorpay_key_id ||
    (typeof process !== 'undefined' && process.env ? process.env.RAZORPAY_KEY_ID || process.env.VITE_RAZORPAY_KEY_ID || process.env.RAZORPAY_LIVE_KEY_ID || process.env.razorpay_key_id : '') ||
    '';

  const rawKeySecret =
    safeEnv.RAZORPAY_KEY_SECRET ||
    safeEnv.RAZORPAY_SECRET ||
    safeEnv.RAZORPAY_LIVE_KEY_SECRET ||
    safeEnv.RAZORPAY_API_SECRET ||
    safeEnv.razorpay_key_secret ||
    (typeof process !== 'undefined' && process.env ? process.env.RAZORPAY_KEY_SECRET || process.env.RAZORPAY_SECRET || process.env.RAZORPAY_LIVE_KEY_SECRET || process.env.razorpay_key_secret : '') ||
    '';

  return {
    keyId: String(rawKeyId).trim(),
    keySecret: String(rawKeySecret).trim()
  };
}

function toBase64(str: string): string {
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(str, 'utf-8').toString('base64');
  }
  if (typeof btoa === 'function') {
    try {
      return btoa(str);
    } catch {
      const bytes = new TextEncoder().encode(str);
      let bin = '';
      for (let i = 0; i < bytes.length; i++) {
        bin += String.fromCharCode(bytes[i]);
      }
      return btoa(bin);
    }
  }
  return '';
}

async function createOrder(body: any, keyId: string, keySecret: string) {
  const items = Array.isArray(body.items) ? body.items : (Array.isArray(body.cartItems) ? body.cartItems : []);

  let finalTotal = 0;
  if (items.length > 0) {
    const itemTotal = items.reduce((sum: number, item: any) => {
      const price = Math.max(0, Number(item?.price) || 0);
      const qty = Math.max(1, Number(item?.qty) || 1);
      return sum + price * qty;
    }, 0);
    const isFree = itemTotal > 100;
    const rawDelivery = Number(body.deliveryCharge);
    const delivery =
      body.deliveryCharge !== undefined &&
      body.deliveryCharge !== null &&
      Number.isFinite(rawDelivery) &&
      rawDelivery >= 0
        ? Math.round(rawDelivery * 100) / 100
        : (isFree ? 0 : 25);
    finalTotal = itemTotal + delivery;
  } else if (Number(body.amount) > 0) {
    finalTotal = Number(body.amount);
  } else {
    throw new Error('Cart is empty or invalid.');
  }

  const amountInPaise = Math.round(finalTotal * 100);

  if (amountInPaise <= 0) {
    throw new Error('Order total must be greater than zero.');
  }

  const receipt = `zyp_${Date.now().toString(36)}`;
  const authHeader = 'Basic ' + toBase64(`${keyId}:${keySecret}`);

  const res = await fetch('https://api.razorpay.com/v1/orders', {
    method: 'POST',
    headers: {
      Authorization: authHeader,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      amount: amountInPaise,
      currency: 'INR',
      receipt,
      notes: {
        customerName: String(body.customerName || '').slice(0, 50),
        customerPhone: String(body.customerPhone || '').slice(0, 15),
        customerAddress: String(body.customerAddress || '').slice(0, 100)
      }
    })
  });

  const text = await res.text();
  if (!res.ok) {
    let desc = text;
    try {
      const p = JSON.parse(text);
      desc = p?.error?.description || p?.error?.reason || desc;
    } catch {}
    console.error('[Razorpay Order Creation Failed]:', res.status, desc);
    throw new Error(`Razorpay gateway error (${res.status}): ${desc}`);
  }

  const data = JSON.parse(text);
  return {
    success: true,
    orderId: data.id,
    amount: data.amount,
    currency: data.currency,
    keyId,
    isLive: keyId.startsWith('rzp_live_')
  };
}

export default async function handler(req: any, res?: any) {
  try {
    // If invoked with Node.js Serverless runtime (req, res)
    if (res && typeof res.status === 'function') {
      for (const [k, v] of Object.entries(CORS_HEADERS)) {
        res.setHeader(k, v);
      }
      if (req.method === 'OPTIONS') return res.status(204).end();

      const { keyId, keySecret } = getCredentials();
      if (req.method === 'GET') {
        return res.status(200).json({
          success: true,
          service: 'Zypsomart Razorpay Order Creation API',
          status: 'ready',
          keysConfigured: Boolean(keyId && keySecret),
          keyType: keyId ? (keyId.startsWith('rzp_live_') ? 'rzp_live_...' : keyId.startsWith('rzp_test_') ? 'rzp_test_...' : 'configured') : 'missing'
        });
      }

      if (req.method !== 'POST') {
        return res.status(405).json({ success: false, error: 'Method not allowed' });
      }

      if (!keyId || !keySecret) {
        const missing: string[] = [];
        if (!keyId) missing.push('RAZORPAY_KEY_ID');
        if (!keySecret) missing.push('RAZORPAY_KEY_SECRET');
        return res.status(200).json({
          success: false,
          keysConfigured: false,
          missingKeys: missing,
          error: `Razorpay credentials missing in Vercel Environment Variables: ${missing.join(', ')}. Please add them in Vercel Settings -> Environment Variables and redeploy.`
        });
      }

      let body = req.body;
      if (typeof body === 'string') {
        try { body = JSON.parse(body); } catch { body = {}; }
      }
      body = body || {};

      try {
        const orderData = await createOrder(body, keyId, keySecret);
        return res.status(200).json(orderData);
      } catch (err: any) {
        console.error('[Create Order Error]:', err?.message || err);
        return res.status(400).json({ success: false, gatewayError: true, error: err?.message || 'Failed to create order' });
      }
    }

    // Web Standard / Edge Fallback Mode (req is Request)
    const method = req.method;
    if (method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: CORS_HEADERS });
    }

    const { keyId, keySecret } = getCredentials();
    if (method === 'GET') {
      return new Response(
        JSON.stringify({
          success: true,
          service: 'Zypsomart Razorpay Order Creation API',
          status: 'ready',
          keysConfigured: Boolean(keyId && keySecret),
          keyType: keyId ? (keyId.startsWith('rzp_live_') ? 'rzp_live_...' : keyId.startsWith('rzp_test_') ? 'rzp_test_...' : 'configured') : 'missing'
        }),
        { status: 200, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
      );
    }

    if (method !== 'POST') {
      return new Response(JSON.stringify({ success: false, error: 'Method not allowed' }), {
        status: 405,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' }
      });
    }

    if (!keyId || !keySecret) {
      const missing: string[] = [];
      if (!keyId) missing.push('RAZORPAY_KEY_ID');
      if (!keySecret) missing.push('RAZORPAY_KEY_SECRET');
      return new Response(
        JSON.stringify({
          success: false,
          keysConfigured: false,
          missingKeys: missing,
          error: `Razorpay credentials missing in Vercel Environment Variables: ${missing.join(', ')}. Please add them in Vercel Settings -> Environment Variables and redeploy.`
        }),
        { status: 200, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
      );
    }

    const body = await req.json().catch(() => ({}));
    const orderData = await createOrder(body, keyId, keySecret);
    return new Response(JSON.stringify(orderData), {
      status: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' }
    });
  } catch (err: any) {
    console.error('[Create Order Fatal Catch]:', err?.message || err);
    if (res && typeof res.status === 'function') {
      return res.status(500).json({ success: false, error: err?.message || 'Server error' });
    }
    return new Response(
      JSON.stringify({ success: false, gatewayError: true, error: err?.message || 'Failed to create order' }),
      { status: 500, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
    );
  }
}
